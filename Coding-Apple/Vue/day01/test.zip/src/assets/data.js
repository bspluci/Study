//[ {}, {}, {} ... ]


export default [{
    title: "Sinrim station 30 meters away",
    image: "https://p.rmjo.in/moodShot/qqnt2gl5-1024x512.jpg",
    caption: "18년 신축공사한 남향 원룸, 공기청정기 제공 ☀️",
    price: 340000
},
{
    title: "Changdong Aurora Bedroom(Queen-size)",
    image: "https://p.rmjo.in/moodShot/p85wsl40-1024x512.jpg",
    caption: "침실만 따로 있는 공용 셰어하우스입니다. 최대 2인 가능",
    price: 450000
},
{
    title: "Geumsan Apartment Flat",
    image: "https://p.rmjo.in/moodShot/h51acr02-1024x512.jpg",
    caption: "금산오거리 역세권 아파트입니다. 애완동물 불가능 🐶",
    price: 780000
},
{
    title: "Double styled beds Studio Apt",
    image: "https://p.rmjo.in/moodShot/c3ii5yl7-1024x512.jpg",
    caption: "천호동인근 2인용 원룸입니다. 전세 전환가능",
    price: 550000
},
{
    title: "MyeongIl Apartment flat",
    image: "https://p.rmjo.in/moodShot/6ouap4qn-1024x512.jpg",
    caption: "명일동 아파트 월세, 남향, 역 5분거리",
    price: 680000
},
{
    title: "Banziha One Room",
    image: "https://p.rmjo.in/moodShot/ugt8rk70-512x256.jpg",
    caption: "반지하 원룸입니다. 비올 때 물가끔 새는거 빼면 좋아요",
    price: 370000
}];
