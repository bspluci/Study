<template>
  <div class="container text-center mt-5">
      <img src="./../assets/logo.png">
      <h4>조용필</h4>
      <p>프론트엔드개발자</p>
      <hr/>
      <p>김치를 잘 담급니다</p>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>