//버튼0을 누르면.. 
//	버튼0,1,2에 추가된 active라는 클래스 제거
//  버튼0에다가 active라는 클래스 추가 
//	
//	내용0,1,2가 안보여야함
//	내용0이 보여야함

var 버튼들 = document.querySelectorAll('.tab-button');
var 탭내용들 = document.querySelectorAll('.tab-content');

for (let i = 0; i < 3; i++){
	버튼들[i].addEventListener('click',function(){
		버튼들[0].classList.remove('active');
		버튼들[1].classList.remove('active');
		버튼들[2].classList.remove('active');
		버튼들[i].classList.add('active');

		탭내용들[0].classList.remove('show');
		탭내용들[1].classList.remove('show');
		탭내용들[2].classList.remove('show');
		탭내용들[i].classList.add('show');
	});
}	
	
	




for ( var i = 0; i < 3; i++ ){
	console.log('안녕');
	console.log(i);
}









